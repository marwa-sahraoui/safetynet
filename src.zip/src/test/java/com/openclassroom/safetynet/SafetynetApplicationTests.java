package com.openclassroom.safetynet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SafetynetApplicationTests {

    @Test
    void contextLoads() {
    }

}
