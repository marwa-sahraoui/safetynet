package com.openclassroom.safetynet.model;

public class Foyer {

    private String station;
     private String address;
     private PersonWithMedicalRecord personWithMedicalRecord;

    public String getStation() {
        return station;
    }

    public void setStation(String station) {
        this.station = station;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public PersonWithMedicalRecord getPersonWithMedicalRecord() {
        return personWithMedicalRecord;
    }

    public void setPersonWithMedicalRecord(PersonWithMedicalRecord personWithMedicalRecord) {
        this.personWithMedicalRecord = personWithMedicalRecord;
    }

    public Foyer(String station, String address, PersonWithMedicalRecord personWithMedicalRecord) {
        this.station = station;
        this.address = address;
        this.personWithMedicalRecord = personWithMedicalRecord;
    }
    @Override
    public String toString() {
        return "Foyer{" +
                "station='" + station + '\'' +
                ", address='" + address + '\'' +
                ", personWithMedicalRecord=" + personWithMedicalRecord +
                '}';
    }

}
